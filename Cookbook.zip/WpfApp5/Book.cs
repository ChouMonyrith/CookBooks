﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp5
{
    public class Book
    {
        public string FoodName { get; set; }=string.Empty;
        public string FoodType { get; set; }=string.Empty;
        public string Description { get; set; }= string.Empty;
    }
}
