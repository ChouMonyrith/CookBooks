﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Channels;
using System.Threading.Tasks;

namespace WpfApp5
{
    public class DataSource 
    {
        public ObservableCollection<Book> books { get; set; } = new ObservableCollection<Book>
        {
            new (){FoodName="KungPaoChicken",FoodType="ChineseFood",Description="Cut the chicken meat into small cubes, rinse in water, pat dry with paper towels and marinate with the ingredients above for 30 minutes.\r\nMix the sauce ingredients in a small bowl and set aside.\r\nHeat up a wok with one tablespoon of oil and stir-fry the marinated chicken until they are 70% cook. Dish out and set aside. Clean the wok and add in the remaining 2 tablespoons of oil until it's fully heated. Add in the ginger and garlic slices and do a quick stir before adding in the dried red chilies.\r\nStir-fry the dried red chilies until aromatic and smell spicy, then add in the chicken meat. Do a few quick stirs before adding in the roasted peanuts.\r\nAdd the sauce and stir continuously until the chicken meat is nicely coated with the sauce. Add in the scallions, stir to combine well with the chicken, dish out and serve immediately with steamed rice."},
            new (){FoodName="FriedGingerBeef",FoodType="KhmerFood",Description="The ginger is rinsed and salted when finished.\r\nAfter bringing the pan to a boil and adding a small amount of cooking oil, start with the ginger.\r\nAdd the oil, garlic, and beef when the ginger has dried and put aside.\r\nFish sauce is the first spice to add flavor to the fried dish. When using palm sugar, avoid rice! Add the garlic leaves to the bowl after adding the bicheng and pouring the ginger into it."},
            new (){FoodName="TunaEggFriedRice",FoodType="KhmerFood",Description="First, slice the beans, garlic, red onion, garlic and set aside.\r\nHeat a frying pan, add oil and sauté garlic until it turns red and fragrant.\r\nThen add canned fish and fry gently so as not to break the fish too much.\r\nAdd ingredients such as fish sauce, soy sauce, chili sauce and sugar and fry until the fish is slightly dry.\r\nThen add rice, beans and red onion and fry it together until it mixes well.\r\nFinally, fry the rice on a plate and fry an egg on top." },
            new (){FoodName="TomatoesBeef",FoodType="KhmerFood",Description="Wash the beef and slice thinly, while the tomatoes are cut in half.\nBring the pan to a boil, add the red peppers and garlic and add the beef. When the beef is cooked, add the sugar, salt, fish sauce, flour, soup, and a little snail oil.\nTaste as you like and then pour the tomatoes into the pan to cook the vegetables.\nWhen eating, do not forget to add garlic leaves.\nPlease enjoy" },
            new (){FoodName="`ForgFried",FoodType="KhmerFood",Description="Wash the frogs, cut them into small pieces and set aside.\nHit the machine carefully\nAs for the frying method, first put the pan to heat and then add a little oil to the frying pan, add the whipped cream to make it smell good, then add the ingredients and hit again (if you use roasted peppers, please put it in the same way). Then pour in the frog, stir it back, dry it with water, then add the ingredients as described above and add a little plain water to make the ingredients come together well and do not burn the pan.\nTaste to your liking, if delicious enough, add fresh peppers and roasted peanuts.\nFry it again, and finally we have to add the pineapple leaves, stir it all and turn off the heat.\nThis dish is ready, please enjoy!" },
            new (){FoodName="FriedFishWithSuace",FoodType="KhmerFood",Description="Wash the fish in clean water, then fry the fish until dry and put it on a plate.\nPeel a squash, grate it and squeeze the juice. Peel a squash, grate it and squeeze the juice. Peel a squash, grate it and slice it.\nPeel a squash, grate it and squeeze the juice. Wash the tomatoes, then slice them.\nMix the sauce with salt, sugar, flour, soup, stir well and leave aside.\nHeat the oil, then add the vegetables to the frying pan, bring the vegetables back to a boil and add the sauce to the frying pan, then pour over the fish, which is already on the plate" },


        };
        public Book? SelectedBook { get; set; }
    }
    
    
}
